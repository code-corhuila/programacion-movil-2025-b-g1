import app from "./app";
import dotenv from "dotenv";

dotenv.config(); // 👈 Esto debe ir antes de usar process.env

// 👇 Aquí imprimimos para verificar que se cargó correctamente
console.log("ENV PORT:", process.env.PORT);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
