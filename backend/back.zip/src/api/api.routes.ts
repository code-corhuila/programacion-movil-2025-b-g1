import { Router } from "express";
import { apiGet, apiPost } from "./api.controller";
import { userRouter } from "../modules/users/user.routes";

const router = Router();

/* Rutas de prueba */
router.get("/get", apiGet);
router.post("/post", apiPost);

/* Rutas reales */
router.use("/users", userRouter);

export { router };
