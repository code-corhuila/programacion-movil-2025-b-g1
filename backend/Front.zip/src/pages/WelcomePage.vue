<template>
  <IonPage>
    <IonContent class="ion-text-center">
      <div class="container">
        <img src="@/assets/logyumo.png" alt="Yumo Logo" class="logo" />

        <h2 class="titulo">Crea una cuenta</h2>
        <p class="subtitulo">
          Ingresa tu correo electrónico para registrarte en esta aplicación
        </p>

        <IonButton expand="block" class="boton" @click="goToRegister">
          Registrarse
        </IonButton>

        <IonButton expand="block" fill="outline" class="boton-outline" @click="goToGuest">
          Continuar sin iniciar sesión
        </IonButton>
      </div>
    </IonContent>
  </IonPage>
</template>

<script setup lang="ts">
import { IonPage, IonContent, IonButton } from '@ionic/vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const goToRegister = () => {
  router.push('/register')
}

const goToGuest = () => {
  router.push('/home')
}
</script>

<style scoped>
/* 🔲 Contenedor centrado para móvil */
.container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100%;
  background-color: #000000;
  padding: 0 20px;
}

/* 🖼 Logo centrado y bien proporcionado */
.logo {
  width: 150px;
  height: auto;
  margin-bottom: 30px;
}

/* ✍️ Título y subtítulo */
.titulo {
  color: #ffffff;
  font-size: 1.4rem;
  font-weight: 600;
  margin-bottom: 10px;
}

.subtitulo {
  color: #bbbbbb;
  font-size: 0.9rem;
  margin-bottom: 30px;
  text-align: center;
  line-height: 1.4;
}

/* 📌 Botones adaptados a mobile */
.boton {
  --background: #ffffff;
  --color: #000000;
  font-weight: 600;
  border-radius: 8px;
  width: 90%;
  max-width: 300px;
  margin: 0 auto 15px auto;
}

.boton-outline {
  --color: #ffffff;
  --border-color: #ffffff;
  border-radius: 8px;
  width: 90%;
  max-width: 300px;
  margin: 0 auto;
}
</style>
