<template>
  <IonPage>
    <IonContent class="ion-text-center">
      <div class="container">
        <!-- 🖼 Logo -->
        <img src="@/assets/logyumo.png" alt="Yumo Logo" class="logo" />

        <!-- 📝 Formulario -->
        <form @submit.prevent="handleRegister" class="formulario">
          <IonInput
            v-model="nombre"
            placeholder="Nombre"
            class="input"
          ></IonInput>

          <IonInput
            v-model="apellido"
            placeholder="Apellido"
            class="input"
          ></IonInput>

          <IonInput
            v-model="correo"
            type="email"
            placeholder="correo@dominio.com"
            class="input"
          ></IonInput>

          <IonInput
            v-model="contrasena"
            type="password"
            placeholder="Contraseña"
            class="input"
          ></IonInput>

          <IonButton expand="block" type="submit" class="boton">
            Continuar
          </IonButton>
        </form>

        <!-- 🔙 Botón volver -->
        <IonButton expand="block" fill="clear" class="boton-volver" @click="goBack">
          ← Volver
        </IonButton>
      </div>
    </IonContent>
  </IonPage>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { IonPage, IonContent, IonInput, IonButton } from '@ionic/vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const nombre = ref('')
const apellido = ref('')
const correo = ref('')
const contrasena = ref('')

const handleRegister = () => {
  console.log('Formulario:', {
    nombre: nombre.value,
    apellido: apellido.value,
    correo: correo.value,
    contrasena: contrasena.value
  })
}

const goBack = () => {
  router.push('/welcome')
}
</script>

<style scoped>
/* 📱 Contenedor oscuro centrado */
.container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100%;
  background-color: #000000;
  padding: 0 20px;
}

/* 🖼 Logo */
.logo {
  width: 150px;
  height: auto;
  margin-bottom: 30px;
}

/* 📝 Formulario */
.formulario {
  width: 90%;
  max-width: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* Campos de texto */
.input {
  width: 100%;
  margin-bottom: 15px;
  --background: #ffffff;
  --color: #000000;
  border-radius: 8px;
  padding-left: 10px;
  font-size: 0.95rem;
}

/* Botón principal */
.boton {
  --background: #ffffff;
  --color: #000000;
  font-weight: 600;
  border-radius: 8px;
  width: 100%;
  margin-top: 10px;
}

/* Botón volver */
.boton-volver {
  margin-top: 20px;
  color: #bbbbbb;
  font-size: 0.9rem;
  text-transform: none;
}
</style>
